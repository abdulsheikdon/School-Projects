To open the project follow these steps as I could not figure out a way to properly export the project
without corrupting it.

1.  Have Microsoft Visual Studio downloaded and open it
2.  Click "Create a new project"
3.  Click "Python Application" on the left under Project Templates and press next at the bottom
4.  Type "webserver" into the project name and save it to a location and press create
5.  Open the webserver.txt file in the assignment 1 folder I submitted and paste it into the Visual Studio
6.  Save the project and open a secondary Visual Studio project by double pressing the Visual Studio icon or
    by searching it in the taskbar search (by looking up Visual Studio and pressing it)
7.  Follow steps 2-3
8.  Type "webclient" into the project name and save it to separate location from webserver and press create
9.  Open the webclient.txt file in the assignment 1 folder and paste it into the Visual Studio
10. Save the project
11. To test the project, run the webserver project first (by pressing the Start button with the green triangle)
12. Once the Command Prompt pops up, it'll say the server is waiting; now type the link
    localhost:2600/HelloWorld.html into a browser. It'll produce the same result as the screenshot
13. Now run the webclient project by pressing Start
14. It should print out onto a new console and you have to type these in exactly
	localhost
	2600
	HelloWorld.html