package edu.ics372.pa2;

/**
 * 
 * This class extends class Exhibit and is the child of it
 * 
 * @author Abdullahi Sheikdon
 *
 */
public class Sculpture extends Exhibit {

	private Room rooms;

	/**
	 * constructor that sets the name, artist, and year using the superclass
	 * 
	 * @param the sculpture's name
	 * @param the artist's name
	 * @param the year in which the sculpture was created
	 */
	public Sculpture(String name, String artist, int year) {
		super(name, artist, year);
	}

	/**
	 * the room's setter
	 * 
	 * @param room (which sculpture is in)
	 */
	public void setRoom(Room room) {
		this.rooms = room;
		room.addExhibit(this);
	}

	/**
	 * overrides parent class
	 * 
	 * @return returns string which matches the PA2 paper
	 */
	@Override
	public String toString() {
		return "Sculpture Exhibit " + "[name= " + getName() + ", artist= " + getArtist() + ", year= " + getYear()
				+ "] room " + rooms.getName();
	}

}
