package edu.ics372.pa2;

import java.util.ArrayList;
import java.util.List;

/**
 * This method extends the class MuseumEntity and is the child of it
 * 
 * @author Abdullahi Sheikdon
 *
 */

public class Room extends MuseumEntity {

	/**
	 * field to store walls into list walls
	 */
	private List<Wall> walls;

	/**
	 * field to store sculptures into list sculptures
	 */
	private List<Exhibit> sculptures;

	/**
	 * constructor that sets the name using the superclass the instances this.walls
	 * and this.sculptures gets initialized
	 * 
	 * @param room's name
	 */
	public Room(String name) {
		super(name);
		this.walls = new ArrayList<Wall>();
		this.sculptures = new ArrayList<Exhibit>();
	}

	/**
	 * Gathers all items on the walls into the variable "museumExhibits"
	 * 
	 * @return returns all Exhibit objects in the room including paintings
	 */
	@Override
	public List<Exhibit> getExhibits() {
		List<Exhibit> museumExhibits = new ArrayList<Exhibit>();
		for (Wall wall : walls) {
			museumExhibits.addAll(wall.getExhibits());
		}
		museumExhibits.addAll(this.sculptures);
		return museumExhibits;
	}

	/**
	 * This method creates walls as an object
	 * 
	 * @param This method has a parameter for the name of the wall
	 * @return returns the Wall object created
	 */
	public Wall addWall(String name) {
		Wall newWall = new Wall(name);
		walls.add(newWall);
		return newWall;
	}

	/**
	 * the getter for wall
	 * 
	 * @return returns the list walls
	 */
	public List<Wall> getWalls() {
		return walls;
	}

	/**
	 * adds the exhibit item
	 * 
	 * @param the object exhibit
	 */
	public void addExhibit(Exhibit exhibit) {
		sculptures.add(exhibit);
	}

}
