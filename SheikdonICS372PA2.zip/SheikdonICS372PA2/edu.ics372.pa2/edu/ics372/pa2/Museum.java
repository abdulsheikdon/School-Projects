package edu.ics372.pa2;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author Abdullahi Sheikdon
 *
 */

public class Museum extends MuseumEntity {

	/**
	 * Field to store the rooms into List "room"
	 */

	private List<Room> room;

	/**
	 * constructor that sets the name using the superclass the instance this.room
	 * gets initialized
	 * 
	 * @param Museum name
	 */

	public Museum(String name) {
		super(name);
		this.room = new ArrayList<Room>();
	}

	/**
	 * Overrides getExhibits() to return all Exhibit objects in the museum
	 * 
	 * @return returns the list "museumExhibit"
	 */

	@Override
	public List<Exhibit> getExhibits() {
		List<Exhibit> museumExhibits = new ArrayList<Exhibit>();
		for (Room altRoom : room) {
			museumExhibits.addAll(altRoom.getExhibits());
		}
		return museumExhibits;
	}

	/**
	 * This method adds a new Room object
	 * 
	 * @param the name of the room
	 * @return returns the newRoom object
	 */

	public Room addRoom(String name) {
		Room newRoom = new Room(name);
		room.add(newRoom);
		return newRoom;
	}

	/**
	 * 
	 * @return returns the list room
	 */
	public List<Room> getRooms() {
		return room;
	}

	/**
	 * 
	 * @param sets the instance of this.room to room
	 */
	public void setRooms(List<Room> rooms) {
		this.room = rooms;
	}
}