package edu.ics372.pa2;

/**
 * 
 * This class extends Exhibit and is the child of it
 * 
 * @author Abdullahi Sheikdon
 *
 */
public class Painting extends Exhibit {

	private Wall walls;

	/**
	 * constructor that sets the name, artist, and year using the superclass
	 * 
	 * @param name, artist, and year which are the relevant details to the art
	 *              pieces
	 */
	public Painting(String name, String artist, int year) {
		super(name, artist, year);
	}

	/**
	 * sets the wall on which the painting is displayed
	 * 
	 * @param the wall
	 */
	public void setWall(Wall wall) {
		this.walls = wall;
		wall.addExhibit(this);
	}

	/**
	 * string that overrides the parent class this was written so it would match the
	 * output in the PA2 paper
	 * 
	 * @return returns string statement
	 */
	@Override
	public String toString() {
		return "Painting Exhibit [name=" + getName() + ", artist=" + getArtist() + ", year=" + getYear() + "] on wall "
				+ walls.getName();
	}

	/**
	 * the wall's getter
	 * 
	 * @return returns wall
	 */
	public Wall getWall() {
		return walls;
	}
}
