package edu.ics372.pa2;

public abstract class MuseumEntity implements Entity {
	/**
	 * name of museum entity
	 */
	private String name;

	/**
	 * constructor of MuseumEnity
	 * 
	 * @param name of museum entity
	 */
	public MuseumEntity(String name) {
		this.name = name;
	}

	/**
	 * getter for name
	 */
	public String getName() {
		return name;
	}

}