package edu.ics372.pa2;

import java.util.List;

/**
 * 
 * @author Abdullahi Sheikdon
 *
 */

public interface Entity {

	/**
	 * @return returns name as a string
	 **/

	public String getName();

	/**
	 * Method to store list of exhibits
	 * 
	 * @return prints exhibit's List
	 **/
	public List<Exhibit> getExhibits();

}