package edu.ics372.pa2;

/**
 * 
 * @author Abdullahi Sheikdon
 *
 */

public class Exhibit {

	private String name; // name of the piece
	private String artist; // artist's name
	private int year; // the year the piece was created

	/**
	 * Constructor of exhibit
	 * 
	 * @param the parameter artist is a string and is the name of the artist
	 * @param the parameter name is a string and is the name of the piece
	 * @param the parameter year is an int and is the piece's date
	 */
	public Exhibit(String name, String artist, int year) {
		this.artist = artist;
		this.name = name;
		this.year = year;
	}

	/**
	 * the name's getter
	 * 
	 * @return returns name
	 */
	public String getName() {
		return name;
	}

	/**
	 * the name's setter
	 * 
	 * @param sets the instance of this.name to name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * the name's getter
	 * 
	 * @return returns the artist
	 */
	public String getArtist() {
		return artist;
	}

	/**
	 * the artist's setter
	 * 
	 * @param sets the instance of this.artist to artist
	 */
	public void setArtist(String artist) {
		this.artist = artist;
	}

	/**
	 * the year's getter
	 * 
	 * @return returns the year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * the year's setter
	 * 
	 * @param sets the instance of this.year to year
	 */
	public void setYear(int year) {
		this.year = year;
	}
}
