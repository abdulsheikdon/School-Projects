package edu.ics372.pa2;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * this class extends the MuseumEntity and is the child of that class
 * 
 * @author Abdullahi Sheikdon
 *
 */
public class Wall extends MuseumEntity {

	/**
	 * field to store the paintings on this wall
	 */
	private List<Exhibit> paintings;

	/**
	 * constructor that sets the name using the superclass the instance
	 * this.painting gets initialized
	 * 
	 * @param the parameter is the name of wall
	 * 
	 */
	public Wall(String name) {
		super(name);
		this.paintings = new ArrayList<Exhibit>();
	}

	/**
	 * getter for the exhibit
	 * 
	 * @return returns all Exhibit objects on the wall which in this case is
	 *         paintings
	 */
	@Override
	public List<Exhibit> getExhibits() {
		return paintings;
	}

	/**
	 * adds all the items in the room to the exhibit
	 * 
	 * @param exhibit
	 */
	public void addExhibit(Exhibit exhibit) {
		paintings.add(exhibit);
	}

	/**
	 * Overrides toString from parent class returns string statement
	 */

	@Override
	public String toString() {
		return "Wall " + this.getName();
	}

}
