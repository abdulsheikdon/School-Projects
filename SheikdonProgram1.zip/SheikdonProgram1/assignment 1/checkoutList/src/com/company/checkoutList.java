public class checkoutList {

    private final int bookMaxAmount = 5;

    private String patron;
    private Book[] books;
    private int numBooks;

    public checkoutList(String patronSecond) {
        patron = patronSecond;
        books = new Book[bookMaxAmount];
        for(int bookIndex = 0; bookIndex < bookMaxAmount; bookIndex++) {
            books[bookIndex] = null;
        }
        numBooks = 0;
    }

    public float getTotal() {

        float total = 0;
        for(int bookIndex = 0; bookIndex < numBooks; bookIndex++) {
            total += books[bookIndex].getReplacementCost();
        }
        return total;
    }

    public double getTotalWeight() {
        double total = 0;
        for(int index = 0; index < numBooks; index++) {
            total += books[index].getWeight();
        }
        return total;
    }

    public void addBook (String name, float replacementCost, int checkoutPeriod, double weight) {
        if (numBooks == bookMaxAmount) {
            System.out.println("The checkout list is full, you can't add more books");
        }
        else {
            Book newBook = new Book(name, replacementCost, checkoutPeriod, weight);
            books[numBooks] = newBook;
            numBooks++;
        }
    }

    public void adjustReplacementCost(int bookNum, float replacementCostAdjustment) {
        if(numBooks == 0) {
            System.out.println("the Checklist is empty");
        }
        else if(bookNum < 0 || bookNum > numBooks -1) {
            System.out.println("bookNum is out of range, make it between 0 and " + (numBooks-1));
        }
        else {
            books[bookNum].adjustReplacementCost(replacementCostAdjustment);
        }
    }

    @Override

    public String toString() {
        String checkoutList = "Patron: " + patron + System.lineSeparator() + "Books:" + System.lineSeparator();
        for(int index = 0; index < numBooks; index++) {
            checkoutList += books[index].toString() + System.lineSeparator();
        }
        checkoutList += "Weight of all the books: " + getTotalWeight();
        return checkoutList;
    }
}
