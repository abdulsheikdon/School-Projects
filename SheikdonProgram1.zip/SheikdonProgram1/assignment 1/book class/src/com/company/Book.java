/** source: https://www.infoworld.com/article/3305792/comparing-java-objects-with-equals-and-hashcode.html
 * I used it for reference since it had a template **/

public class Book {

    private String name;

    private double weight;

    private int checkoutPeriod;

    private float replacementCost;

    public Book (String name, double weight, int checkoutPeriod, float replacementCost) {
        super();
        this.name = name;
        this.weight = weight;
        this.checkoutPeriod = checkoutPeriod;
        this.replacementCost = replacementCost;
    }
    public String getName() {
        return name;
    }
    public double getWeight() {
        return weight;
    }
    public int getCheckoutPeriod() {
        return checkoutPeriod;
    }
    public float getReplacementCost() {
        return replacementCost;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setWeight(double weight) {
        this.weight = weight;
    }
    public void setCheckoutPeriod(int checkoutPeriod) {
        this.checkoutPeriod = checkoutPeriod;
    }
    public void setReplacementCost(float replacementCost) {
        this.replacementCost = replacementCost;
    }
    public void adjustReplacementCost(double amount) {
        this.replacementCost += amount;
    }

    @Override

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Book other = (Book) obj;
        return Objects.equals(this.name, other.name)
                && this. weight == other.weight;
    }

    @Override

    public String toString() {

        return "Name: " + name + System.lineSeparator() + "Weight: " + weight + System.lineSeparator() +
                "Checkout Period: " + checkoutPeriod + System.lineSeparator() + "Replacement Cost: " + replacementCost;
    }
}
