public class checkoutDriver {

    public static void main(String[] args) {
        checkoutList personOneCheckout = new checkoutList("Person One");
        checkoutList personTwoCheckout = new checkoutList("Person Two");
        personOneCheckout.addBook("Hunger Games", 6, 7, 5f);
        personOneCheckout.addBook("Fahrenheit 451", 7, 1, 3f);
        personOneCheckout.addBook("Handmaiden's Tale", 2, 5, 7f);
        personTwoCheckout.addBook("One Piece", 2, 2, 11f);
        personTwoCheckout.addBook("Lord of the Flies", 7, 9, 8f);
        personTwoCheckout.adjustReplacementCost(1, 2);
        System.out.println("First Customer Checkout List:");
        System.out.println(personOneCheckout.toString());
        System.out.println();
        System.out.println();
        System.out.println("Second Customer Checkout List:");
        System.out.println(personTwoCheckout.toString());
        System.out.println();
        System.out.println("Testing the code");
        personOneCheckout.addBook("One Piece", 2, 2, 8f);
        personOneCheckout.addBook("Lord of the Flies", 7, 9, 4f);
        System.out.println("Adding a test book for when the list is filled:");
        System.out.println("Adding a book called 'fake book' with 0 weight 0 checkout period and 0 replacement cost")
        personOneCheckout.addBook("fake book", 0, 0, 0);
        System.out.println();
        System.out.println("Adjusting the cost for when bookNum invalid:");
        personTwoCheckout.adjustReplacementCost(2, 2);
        personOneCheckout.adjustReplacementCost(2, -2);
        System.out.println();
        System.out.println("First Checkout List - After adjusting bookNum 2 by -2:");
        System.out.println(personOneCheckout.toString());
        System.out.println();
        System.out.println("All Replacement Costs for the First Checkout: " + personOneCheckout.getTotal());
        System.out.println("All Replacement Costs for the Second Checkout: " + personTwoCheckout.getTotal());
    }
}
