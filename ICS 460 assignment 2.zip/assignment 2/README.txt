To open the project follow these steps as I could not figure out a way to properly export the project
without corrupting it.

1.  Have Microsoft Visual Studio downloaded and open it
2.  Click "Create a new project"
3.  Click "Python Application" on the left under Project Templates and press next at the bottom
4.  Type "serverside" into the project name and save it to a location and press create
5.  Open the serverside.txt file in the assignment 1 folder I submitted and paste it into the Visual Studio
6.  Save the project and open a secondary Visual Studio project by double pressing the Visual Studio icon or
    by searching it in the taskbar search (by looking up Visual Studio and pressing it)
7.  Follow steps 2-3
8.  Type "clientside" into the project name and save it to separate location from webserver and press create
9.  Open the webclient.txt file in the assignment 1 folder and paste it into the Visual Studio
10. Save the project
11. In order to have multiple clients, repeat steps 7-10 for the amount of clients you wish to have
12. To test the project, run the serverside project first (by pressing the Start button with the green triangle)
    then subsequently run each client side project that you have
13. It should run properly

The files that are present are 2 files, serverside.txt and clientside.txt which are meant to be pasted into
Microsoft Visual Studio