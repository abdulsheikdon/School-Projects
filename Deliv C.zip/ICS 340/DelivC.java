import java.io.*;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;


public class DelivC{

	private File inputFile;
	private File outputFile;
	private PrintWriter output;
	private Graph graph;
	private int totalPrimDistance;

	//Constructor - DO NOT MODIFY
	public DelivC(File in, Graph gr) {
		inputFile = in;
		graph = gr;

		// Set up for writing to a file
		try {
			// Use input file name to create output file in the same location
			String inputFileName = inputFile.toString();
			String outputFileName = inputFileName.substring(0, inputFileName.length() - 4).concat("_out.txt");
			outputFile = new File(outputFileName);

			// A Printwriter is an object that can write to a file
			output = new PrintWriter(outputFile);
		} catch (Exception x) {
			System.err.format("Exception: %s%n", x);
			System.exit(0);
		}
		
		// Calls the method that will do the work of deliverable C
		runDelivC();

		output.flush();
	}

	//*********************************************************************************
	//               This is where your work starts
	
	private void runDelivC() {
		//Delete these lines when you add functionality
		System.out.println("DelivC:  To be implemented");//Prints to console
		//output.println("DelivC:  To be implemented");//Prints to file
		MSTPrim();
//		for (Node u : graph.getNodeList()) {
//			System.out.println(u);
//		}

		System.out.println("The minimum spanning tree has a total cost of " + totalPrimDistance + " and includes the following edges:");
		MSTPrim2(); //this is ran a second time 
//		for (Edge output : graph.getEdgeList()) {
//			System.out.println(output.getTail().getAbbrev() + " -> " + output.getHead().getAbbrev());
//			}
		
	}
	
	public void MSTPrim () {
		for (Node u : graph.getNodeList()) {
			u.setKey(Integer.MAX_VALUE);
			u.setPredecessor(null);
		}
		//start is r
		Node start = graph.findStart();
		start.setKey(0);
		PriorityQueue<Node> Q = new PriorityQueue<Node>();
		for (Node u : graph.getNodeList()) {
			Q.add(u);// adds all the nodes
		}
		while (!Q.isEmpty()) {
			Node u = Q.poll();
			for (Edge edge : u.getOutgoingEdges()) {
				Node v = edge.getHead();
				if (Q.contains(v) && edge.getDistance() < v.getKey()) {
					v.setPredecessor(u);
					v.setKey(edge.getDistance());
					Q.remove(v);
					Q.add(v);
				}
			}
			Q.remove(u);
			Q.remove(u.getPredecessor());
			totalPrimDistance = totalPrimDistance + u.getKey();
		}
	}
	public void MSTPrim2 () {
		for (Node u : graph.getNodeList()) {
			u.setKey(Integer.MAX_VALUE);
			u.setPredecessor(null);
		}
		//start is r
		Node start = graph.findStart();
		start.setKey(0);
		PriorityQueue<Node> Q = new PriorityQueue<Node>();
		for (Node u : graph.getNodeList()) {
			Q.add(u);// adds all the nodes
		}
		while (!Q.isEmpty()) {
			Node u = Q.poll();
			for (Edge edge : u.getOutgoingEdges()) {
				Node v = edge.getHead();
				if (Q.contains(v) && edge.getDistance() < v.getKey()) {
					v.setPredecessor(u);
					v.setKey(edge.getDistance());
					Q.remove(v);
					Q.add(v);
				}
			}
			Q.remove(u);
			Q.remove(u.getPredecessor());
			if (u.getPredecessor() != null) {
				System.out.println(u + "->" + u.getPredecessor());
			}
		}
	}
}

