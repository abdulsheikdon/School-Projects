import java.io.*;
import java.util.Collections;
import java.util.Comparator;

public class DelivB {

	private File inputFile;
	private File outputFile;
	private PrintWriter output;
	private Graph graph;
	private static int time;

	//Constructor - DO NOT MODIFY
	public DelivB(File in, Graph gr) {
		inputFile = in;
		graph = gr;

		// Set up for writing to a file
		try {
			// Use input file name to create output file in the same location
			String inputFileName = inputFile.toString();
			String outputFileName = inputFileName.substring(0, inputFileName.length() - 4).concat("_out.txt");
			outputFile = new File(outputFileName);

			// A Printwriter is an object that can write to a file
			output = new PrintWriter(outputFile);
		} catch (Exception x) {
			System.err.format("Exception: %s%n", x);
			System.exit(0);
		}
		
		// Calls the method that will do the work of deliverable B
		runDelivB();

		output.flush();
	}

	//*********************************************************************************
	//               This is where your work starts
	
	private void runDelivB() {
		//Delete these lines when you add functionality
		System.out.println("DelivB:  To be implemented");//Prints to console
		//output.println("DelivB:  To be implemented");//Prints to file
		
		System.out.println();
		System.out.println("DFS of graph");
		System.out.println();
		System.out.println("Node\tDiscovery\tFinish");

		// classify edges
		DFS();
		for (Node output : graph.getNodeList()) {
			System.out.println(output.getAbbrev() + "\t" + output.getDiscoveryTime() + "\t\t" + output.getFinishTime());
		}
		System.out.println();
		System.out.println("Edge Classification:");
		System.out.println();
		System.out.println("Edge\tType");
		EdgeClassification();
		for (Edge output2 : graph.getEdgeList()) {
			System.out.println(output2.getTail().getAbbrev() + " -> " + output2.getHead().getAbbrev() + "\t" + output2.getEdgeType());
			}
		}
	
	public void DFS() {
		Node start = graph.findStart();
		// nodeComparer sort the graph before using the node comparer
		Collections.sort(graph.getNodeList(), new NodeComparer());
		for (Node u : graph.getNodeList()) {
			u.setColor("white");
			u.setPredecessor(null);
		}
		time = 0;
		DFSVisit(start);
		for (Node u : graph.getNodeList()) {
			if (u.getColor().equals("white")) {
				DFSVisit(u);
			}
		}
	}

	public void DFSVisit(Node u) {
		time = time + 1;
		u.setDiscoveryTime(time);
		u.setColor("gray");
		// edge comparator sort thru graph collections.sort
		Collections.sort(u.getOutgoingEdges(), new EdgeComparer());
		for (Edge edge : u.getOutgoingEdges()) {
			Node v = edge.getHead();
			if (v.getColor().equals("white")) {
				v.setPredecessor(u);
				edge.setEdgeType("Tree");
				DFSVisit(v);
			}
		}
		u.setColor("black");
		time = time + 1;
		u.setFinishTime(time);
	}
	
	private class EdgeComparer implements Comparator<Edge> {

		@Override
		public int compare(Edge edge1, Edge edge2) {
			if (edge1.getDistance() > edge2.getDistance()) {
				return 1;
			} else if (edge1.getDistance() < edge2.getDistance()) {
				return -1;
			} else {
				return 0;
			}
		}
	}

	private class NodeComparer implements Comparator<Node> {
		@Override
		public int compare(Node node1, Node node2) {
			return node1.getAbbrev().compareToIgnoreCase(node2.getAbbrev());
		}

	}

	public void printEdge() {
		for (Node u : graph.getNodeList()) {
			for (Edge edge : u.getOutgoingEdges()) {
				if (edge.getEdgeType().equals("Tree")) {
					edge.getEdge();
				} else {
					return;
				}
			}
		}
	}
	
	public void EdgeClassification() {
		for (Edge edge : graph.getEdgeList()) {
			Node u = edge.getTail();
			Node v = edge.getHead();
			if (edge.getEdgeType() == null) {
				if (u.getDiscoveryTime() < v.getDiscoveryTime() && u.getFinishTime() > v.getFinishTime()) {
					edge.setEdgeType("Forward");
					// System.out.println("Forward");
				} else if (u.getDiscoveryTime() > v.getDiscoveryTime() && u.getFinishTime() < v.getFinishTime()) {
					edge.setEdgeType("Back");
					// System.out.println("Back");
				} else if (v.getDiscoveryTime() < v.getFinishTime() && v.getFinishTime() < u.getDiscoveryTime()
						&& u.getDiscoveryTime() < u.getFinishTime()) {
					edge.setEdgeType("Cross");
					// System.out.println("Cross");
				}
			}
		}
	}

}

