package edu.ics372.p1;

public interface Shape {

	double getPerimeter();
	
	double getArea();
	
	void draw();

}
