package edu.ics372.p1;
import java.io.*;
import java.util.*;
import java.util.Scanner;


class DriverClass {
	
	
	public static void main (String[] args)
	{
		int a, b;
		Scanner reader = new Scanner(System.in);
		System.out.println("What is the width of the rectangle?");
		a = reader.nextInt();
		
		Scanner reader2 = new Scanner(System.in);
		System.out.println("What is the height of the rectangle?");
		b = reader2.nextInt();
		
		Shape rectangle1 = new Rectangle(a, b);
		System.out.println();
		System.out.println("Proportions of the rectangle: ");
		System.out.println();
		System.out.println("Width: " + a);
		System.out.println("Height: " + b);
		System.out.println();
		System.out.println("Drawing of the rectangle:");
		System.out.println();
		rectangle1.draw();
		reader.close();
		reader2.close();
	}
}
