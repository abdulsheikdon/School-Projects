package edu.ics372.p1;

public class Rectangle implements Shape {

	public double height, width;

	public Rectangle(double width, double height) {
		this.width = width;
		this.height = height;
	}

	@Override

	public void draw() {
		// This is the draw method which draws the actual rectangle
		for(int i = 0; i < height; i++){
			for(int j = 0; j < width; j++){
				System.out.print("*");
			}
			System.out.println();
		}
	}

	@Override

	public double getArea() {
		/** This function gets the area of the rectangle
		 by multiplying the width and height together **/
		return (width * height);
	}

	@Override

	public double getPerimeter() {
		/** this function gets the perimeter by adding width and height but thats only one part
		 	of the rectangle so you have to multiply by two
		 * 
		 */
		return ((width + height) * 2);
	}

	public String toString() {
		return "Width = " + this.width + " and Height = " + this.height;
	}


}
