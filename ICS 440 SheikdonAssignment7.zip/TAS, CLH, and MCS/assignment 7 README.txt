Fig 7.33 is an incorrect implementation of the CLH lock because instead of the predecessor node,
it just reuses its own node. It causes problems because it reuses the node even if its not the
tail of the queue. MCS can dodge this issue because it has a different queue filled with nodes
that haven't been reused. The way it works is that it every time a thread gets the lock, it makes
a wait node and adds it to the queue. Once the lock is released, the wait nodes (from the queue) get
removed as well so that it doesn't get reused.