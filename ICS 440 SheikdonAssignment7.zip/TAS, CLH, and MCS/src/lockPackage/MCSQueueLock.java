package lockPackage;

import java.util.concurrent.atomic.AtomicReference;

public class MCSQueueLock {
    private final AtomicReference<QNode> tail;
    private final ThreadLocal<QNode> myNode;

    public MCSQueueLock() {
        tail = new AtomicReference<>();
        myNode = ThreadLocal.withInitial(QNode::new);
    }

    public boolean isLocked() {
        return tail.get() != null;
    }

    public void lock() {
        QNode qnode = myNode.get();
        QNode pred = tail.getAndSet(qnode);
        if (pred != null) {
            qnode.locked = true;
            pred.next = qnode;
            while (qnode.locked);
        }
    }

    public void unlock() {
        QNode qnode = myNode.get();
        if (qnode.next == null) {
            if (tail.compareAndSet(qnode, null)) {
                return;
            }
            while (qnode.next == null);
        }
        qnode.next.locked = false;
        qnode.next = null;
    }

    private static class QNode {
        volatile boolean locked;
        QNode next;
    }
}


