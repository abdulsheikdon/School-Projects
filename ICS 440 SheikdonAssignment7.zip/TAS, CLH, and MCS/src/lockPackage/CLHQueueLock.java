package lockPackage;

import java.util.concurrent.atomic.AtomicReference;

public class CLHQueueLock {
    private AtomicReference<QNode> tail;
    private ThreadLocal<QNode> myPred;
    private ThreadLocal<QNode> myNode;

    public CLHQueueLock() {
        tail = new AtomicReference<>(new QNode());
        myNode = ThreadLocal.withInitial(QNode::new);
        myPred = ThreadLocal.withInitial(() -> null);
    }

    public boolean isLocked() {
        QNode qnode = myNode.get();
        return qnode.locked || qnode.pred != null;
    }

    public void lock() {
        QNode qnode = myNode.get();
        qnode.locked = true;
        QNode pred = tail.getAndSet(qnode);
        myPred.set(pred);
        while (pred.locked);
    }

    public void unlock() {
        QNode qnode = myNode.get();
        qnode.locked = false;
        myNode.set(myPred.get());
    }

    private static class QNode {
        volatile boolean locked;
        QNode pred;
    }
}

