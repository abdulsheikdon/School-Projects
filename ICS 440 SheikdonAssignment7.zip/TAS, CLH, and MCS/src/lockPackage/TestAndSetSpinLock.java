package lockPackage;

import java.util.concurrent.atomic.AtomicBoolean;

public class TestAndSetSpinLock {
    private AtomicBoolean locked = new AtomicBoolean(false);

    public boolean isLocked() {
        return locked.get();
    }

    public void lock() {
        while (locked.getAndSet(true));
    }

    public void unlock() {
        locked.set(false);
    }
}

