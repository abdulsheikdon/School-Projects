package lockPackage;

public class Main {
    public static void main(String[] args) {
        TestAndSetSpinLock tasLock = new TestAndSetSpinLock();
        CLHQueueLock clhLock = new CLHQueueLock();
        MCSQueueLock mcsLock = new MCSQueueLock();

        System.out.println("Is the TAS Lock locked?\t " + tasLock.isLocked());
        tasLock.lock();
        System.out.println("Is the TAS Lock locked?\t " + tasLock.isLocked());
        tasLock.unlock();
        System.out.println("Is the TAS Lock locked?\t " + tasLock.isLocked());
        System.out.println();
        

        System.out.println("Is the CLH Lock locked?\t " + clhLock.isLocked());
        clhLock.lock();
        System.out.println("Is the CLH Lock locked?\t " + clhLock.isLocked());
        clhLock.unlock();
        System.out.println("Is the CLH Lock locked?\t " + clhLock.isLocked());
        System.out.println();
        
        
        System.out.println("Is the MCS Lock locked?\t " + mcsLock.isLocked());
        mcsLock.lock();
        System.out.println("Is the MCS Lock locked?\t " + mcsLock.isLocked());
        mcsLock.unlock();
        System.out.println("Is the MCS Lock locked?\t " + mcsLock.isLocked());
    }
}


