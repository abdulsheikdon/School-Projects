package chapter16;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MatrixMulTask {
    double[][] lhs, rhs, prod;
    int n;

    public MatrixMulTask(double[][] lhs, double[][] rhs) {
        n = lhs.length;
        this.lhs = lhs;
        this.rhs = rhs;
        this.prod = new double[n][n];
    }

    public void multiply() {
        ExecutorService executor = Executors.newFixedThreadPool(n);
        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {
                Worker worker = new Worker(row, col);
                executor.execute(worker);
            }
        }
        executor.shutdown();
        while (!executor.isTerminated()) {
            // wait for all tasks to complete
        }
    }

    class Worker implements Runnable {
        int row, col;

        public Worker(int row, int col) {
            this.row = row;
            this.col = col;
        }

        @Override
        public void run() {
            for (int i = 0; i < n; i++) {
                prod[row][col] += lhs[row][i] * rhs[i][col];
            }
        }
    }
}

