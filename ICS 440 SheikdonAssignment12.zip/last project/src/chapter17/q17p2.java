package chapter17;

import java.util.stream.LongStream;

public class q17p2 {

    private static boolean isPrime(long n) {
        if (n < 2) {
            return false;
        }
        return LongStream.rangeClosed(2, (long) Math.sqrt(n))
        		
                .noneMatch(i -> n % i == 0);
    }

    private static long countPrimes(int max) {
        return LongStream.range(2, max)
                .filter(q17p2::isPrime)
                .count();
    }

    public static void main(String[] args) {
        // Test isPrime method
        System.out.println("Is 2 prime?\t" + isPrime(2)); // true
        System.out.println("Is 4 prime?\t" + isPrime(4)); // false
        System.out.println("Is 11 prime?\t" + isPrime(11)); // true
        System.out.println("Is 15 prime?\t" + isPrime(15)); // false
        
        // Test countPrimes method
        System.out.println("Count 10's primes = " + countPrimes(10)); // 4
        System.out.println("Count 20's primes = " + countPrimes(20)); // 8
        System.out.println("Count 30's primes = " + countPrimes(30)); // 10
    }
}


