package chapter17;

import java.util.Arrays;
import java.util.Comparator;

public class q17p1 {
    public static void main(String[] args) {
        String[] strings = {"alpha", "bravo", "charlie", "delta", "echo"};

        // sort strings by length, shortest first
        Arrays.sort(strings, Comparator.comparingInt(String::length));
        System.out.println(Arrays.asList(strings));

        // sort strings by their second letter
        Arrays.sort(strings, Comparator.comparing(s -> s.substring(1, 2)));
        System.out.println(Arrays.asList(strings));

        // order strings that start with 'c' first, then sort normally
        Arrays.sort(strings, Comparator.comparing((String s) -> s.startsWith("c") ? 0 : 1)
                                 .thenComparing(Comparator.naturalOrder()));
        System.out.println(Arrays.asList(strings));
    }
}

