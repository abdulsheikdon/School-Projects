package question2;

class FullException extends RuntimeException {
    public FullException() {
        super("Stack is full");
    }
}

class EmptyException extends RuntimeException {
    public EmptyException() {
        super("Stack is empty");
    }
}


public class ArrayBasedStack<T> {
    int capacity; // size of array
    int top; // index of first empty slot
    T[] items; // array of items

    public ArrayBasedStack(int myCapacity) {
        capacity = myCapacity;
        items = (T[]) new Object[capacity];
        top = 0;
    }

    public void push(T x) throws FullException {
        if (top == capacity) {
            throw new FullException();
        }
        items[top++] = x;
    }

    public T pop() throws EmptyException {
        if (top == 0) {
            throw new EmptyException();
        }
        T result = items[--top];
        items[top] = null; // Avoid memory leak
        return result;
    }

    public T peek() throws EmptyException {
        if (top == 0) {
            throw new EmptyException();
        }
        return items[top - 1];
    }

    public boolean isEmpty() {
        return top == 0;
    }

    public boolean isFull() {
        return top == capacity;
    }
}

