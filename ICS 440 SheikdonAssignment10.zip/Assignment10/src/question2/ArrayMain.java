package question2;

public class ArrayMain {
    public static void main(String[] args) {
        ArrayBasedStack<Integer> stack = new ArrayBasedStack<>(3);

        // Test pushing elements onto the stack
        stack.push(1);
        stack.push(2);
        stack.push(3);

        // Test trying to push an element onto a full stack
        System.out.println("Pushing onto full stack: ");
        try {
            stack.push(4);
        } catch (FullException e) {
            System.out.println(e.getMessage());
        }
        System.out.println();

        // Test peeking at the top element of the stack
        System.out.println("Peek:");
        try {
            System.out.println(stack.peek());
        } catch (EmptyException e) {
            System.out.println(e.getMessage());
        }
        System.out.println();

        // Test popping elements off the stack
        System.out.println("Popping stack:");
        while (!stack.isEmpty()) {
            System.out.println(stack.pop());
        }
        System.out.println();

        // Test trying to pop an element off an empty stack
        System.out.println("Popping stack on empty array:");
        try {
            stack.pop();
        } catch (EmptyException e) {
            System.out.println(e.getMessage());
        }
    }
}

