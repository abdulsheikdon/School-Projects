package question1;

public class ListMain {
    public static void main(String[] args) {
        ListBasedStack<Integer> stack = new ListBasedStack<>(3);

        // Push some elements onto the stack
        try {
            stack.push(1);
            stack.push(2);
            stack.push(3);
        } catch (FullException e) {
            System.out.println(e.getMessage()); // Should not reach here
        }

        // Try to push onto a full stack
        System.out.println("Pushing onto full stack: ");
        try {
            stack.push(4); // Should throw a FullException
        } catch (FullException e) {
            System.out.println(e.getMessage()); // Should print "Stack is full"
        }
        System.out.println();

        // Pop some elements off the stack and print what was popped off
        System.out.println("Printing the stack:");
        try {
            System.out.println(stack.pop());
            System.out.println(stack.pop());
            System.out.println(stack.pop());
        } catch (EmptyException e) {
            System.out.println(e.getMessage()); // Should not reach here
        }
        System.out.println();

        // This is where I try to pop an element from an empty stack
        System.out.println("Attempting to print after the stack is empty: ");
        try {
            System.out.println(stack.pop()); // Should throw an EmptyException
        } catch (EmptyException e) {
            System.out.println(e.getMessage()); // Should print "Stack is empty"
        }
        System.out.println();
    }
}

