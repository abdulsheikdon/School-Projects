package question1;

import java.util.concurrent.locks.*;

class EmptyException extends Exception {
    public EmptyException() {
        super("Stack is empty");
    }
}

class FullException extends Exception {
    public FullException() {
        super("Stack is full");
    }
}

public class ListBasedStack<T> {
    private Node top;
    private Lock lock;
    private int size;
    private int capacity;

    public ListBasedStack(int capacity) {
        top = null;
        lock = new ReentrantLock();
        size = 0;
        this.capacity = capacity;
    }

    public void push(T x) throws FullException {
        lock.lock();
        try {
            if (size == capacity) {
                throw new FullException();
            }
            top = new Node(x, top);
            size++;
        } finally {
            lock.unlock();
        }
    }

    public T pop() throws EmptyException {
        lock.lock();
        try {
            if (top == null) {
                throw new EmptyException();
            } else {
                T result = top.value;
                top = top.next;
                size--;
                return result;
            }
        } finally {
            lock.unlock();
        }
    }

    private class Node {
        public T value;
        public Node next;

        public Node(T value, Node next) {
            this.value = value;
            this.next = next;
        }
    }
}
