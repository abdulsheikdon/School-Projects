import ssl
from socket import *

serverPort = 12000
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(('', serverPort))
serverSocket.listen(1)

# Add the following lines
context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
context.load_cert_chain(certfile="C:\\cert.pem", keyfile="C:\\key.pem")

print("The server is ready to receive")

while True:
    connectionSocket, addr = serverSocket.accept()

    # Secure the connection
    secureConnection = context.wrap_socket(connectionSocket, server_side=True)

    sentence = secureConnection.recv(1024).decode()
    capitalizedSentence = sentence.upper()
    secureConnection.send(capitalizedSentence.encode())

    secureConnection.close()