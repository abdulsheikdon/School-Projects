package com.company;

public class BuildingType {

    public final String name;
    public final int incomePerUnit;
    private int amount;
    private int price;
    private double priceIncrease;

    public BuildingType(String name, int incomePerUnit, int initialPrice, double priceIncrease) {
        this.name = name;
        this.incomePerUnit = incomePerUnit;
        this.amount = 0;
        this.price = initialPrice;
        this.priceIncrease = priceIncrease;
    }

    public int getPrice(){
        return this.price;
    }

    public void build(){
        this.amount++;
        this.price = (int)Math.ceil(this.price * this.priceIncrease);
    }

    public int getAmount(){
        return this.amount;
    }

    public int totalIncome(){
        return this.amount * this.incomePerUnit;
    }
}
