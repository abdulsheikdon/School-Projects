package com.company;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class IncrementalGame extends JFrame{
    private JPanel outerPanel;
    private JButton moneyButton;
    private JTextField moneyDisplay;
    private JPanel gridPanel;
    private JButton cursorUpgradeButton;
    private JTextField moneyPerClickDisplay;
    private JTextField cursorUpgradePriceDisplay;
    private JButton building0UpgradeButton;
    private JTextField building0UpgradePriceDisplay;
    private JTextField building0IncomeDisplay;
    private JButton building1UpgradeButton;
    private JTextField building1UpgradePriceDisplay;
    private JTextField building1IncomeDisplay;
    private JTextField unit0Amount;
    private JTextField unit1Amount;
    private JButton building2UpgradeButton;
    private JButton building3UpgradeButton;
    private JTextField building2UpgradePriceDisplay;
    private JTextField building3UpgradePriceDisplay;
    private JTextField building2IncomeDisplay;
    private JTextField building3IncomeDisplay;
    private JTextField unit2Amount;
    private JTextField unit3Amount;
    private JTextField frieza1Box;
    private JTextField incurred1DebtToKorin;
    private JTextField final1Profit;
    private Timer timer;
    private Timer secondTimer;
    private Timer interestTimer;
//    private Timer payoutTimer;

    private BuildingType[] buildingTypes = {
            new BuildingType("big brained monkey", 2, 10, 1.8),
            new BuildingType("super monkey",6,40,2.5),
            new BuildingType("super saiyan money",10,100,4),
            new BuildingType("super saiyan 2 monkey", 17,150,4),
    };
    private JButton[] buildingUpgradeButtons = {
            building0UpgradeButton,
            building1UpgradeButton,
            building2UpgradeButton,
            building3UpgradeButton,
    };
    private JTextField[] buildingUpgradeCostDisplays = {
            building0UpgradePriceDisplay,
            building1UpgradePriceDisplay,
            building2UpgradePriceDisplay,
            building3UpgradePriceDisplay,
    };
    private JTextField[] buildingIncomeDisplays = {
            building0IncomeDisplay,
            building1IncomeDisplay,
            building2IncomeDisplay,
            building3IncomeDisplay,
    };
    private JTextField[] buildingAmountDisplays = {
            unit0Amount,
            unit1Amount,
            unit2Amount,
            unit3Amount,
    };

    private int money = 0;
    private int moneyPerClick = 1;
    private int cursorUpgradeCost = 5;
    private int cursorUpgradePriceIncrease = 5;
//    private int unitAmount = 0;

    public IncrementalGame(){
        this.setContentPane(outerPanel);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800,600);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.timer = new Timer(1000, new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                tick();
            }
        });
        this.secondTimer = new Timer(4000, new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                secondTick();
            }
        });
        this.interestTimer = new Timer(4000, new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                interestTick();
            }
        });
//        this.payoutTimer = new Timer(1000, new ActionListener(){
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                finalProfit();
//            }
//        });
        this.timer.start();
        this.secondTimer.start();
        this.interestTimer.start();
//        this.payoutTimer.start();
        updateMoneyDisplay();
        updateClickDisplay();
        for(int i=0;i<buildingTypes.length;i++){
            buildingUpgradeButtons[i].setText("Hire " + buildingTypes[i].name);
            updateBuildingDisplay(i);
        }
        moneyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                click();
            }
        });
        cursorUpgradeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cursorUpgrade();
            }
        });

        building0UpgradeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buildBuilding(0);
            }
        });
        building1UpgradeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buildBuilding(1);
            }
        });
        building2UpgradeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buildBuilding(2);
            }
        });
        building3UpgradeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buildBuilding(3);
            }
        });
    }

    private void click(){
        this.money += this.moneyPerClick;
        updateMoneyDisplay();
    }

    private void tick(){
        int income = 0;
        for(int i=0;i<this.buildingTypes.length;i++){
            income += this.buildingTypes[i].totalIncome();
        }
        this.money += income;
        updateMoneyDisplay();
    }

    private void secondTick(){
        int interest = (int) (this.money*0.5);
        this.incurred1DebtToKorin.setText("The debt owed to Korin has become " + interest + " bananas");
        if(this.money <= 0) {
            this.money = 0;
        }
    }

    //public void finalProfit(){

    //}

    public void interestTick(){
        int interest = (int) (this.money*0.5);
        this.money -= interest;
        this.final1Profit.setText("After paying interest, the total profit has become " + this.money + " bananas");
    }



    private void updateMoneyDisplay(){
        this.moneyDisplay.setText(this.money + " bananas have been produced" );
        //                                  loss V                                                                                                 profitV
        this.frieza1Box.setText((Math.round(this.money*0.1)) + " bananas have been stolen by Frieza resulting in a true profit of " + (this.money-(Math.round(this.money*0.1))) + " bananas");
    }

    private void updateBuildingDisplay(int i){
        this.buildingUpgradeCostDisplays[i].setText("Pay " + this.buildingTypes[i].getPrice() + " bananas");
        this.buildingIncomeDisplays[i].setText(this.buildingTypes[i].totalIncome() + " bananas per second");
        this.buildingAmountDisplays[i].setText(this.buildingTypes[i].getAmount() + " monkeys hired");

    }

    private void updateClickDisplay(){
        this.cursorUpgradePriceDisplay.setText("Eat " + this.cursorUpgradeCost + " bananas");
        this.moneyPerClickDisplay.setText(this.moneyPerClick + " bananas per click");
    }

    private void buildBuilding(int i){
        if((this.money-(Math.round(this.money*0.1))) >= this.buildingTypes[i].getPrice()){
            this.money -= Math.round(this.money*0.1);
            this.money -= this.buildingTypes[i].getPrice();
            this.updateMoneyDisplay();
            this.buildingTypes[i].build();
            updateBuildingDisplay(i);
        }
    }

    private void cursorUpgrade(){
        if((this.money-(Math.round(this.money*0.1))) >= this.cursorUpgradeCost){
            this.money -= Math.round(this.money*0.1);
            this.money -= this.cursorUpgradeCost;
            updateMoneyDisplay();
            this.moneyPerClick++;
            this.cursorUpgradeCost *= this.cursorUpgradePriceIncrease;
            updateClickDisplay();
        }
    }

    public static void main(String[] args) {
        IncrementalGame myGame = new IncrementalGame();
    }

}
