Basically in this code, the saiyan monkeys are harvesting bananas while frieza steals from them.
The saiyan monkey's also incur debt from using Korin's land at Korin's tower.
This is all a Dragon Ball reference.