module edu.ics372.exam2q1 {
	requires javafx.controls;
	requires javafx.base;
	requires java.desktop;

	exports edu.ics372.exam2q1.display to javafx.graphics;
	exports edu.ics372.exam2q1.start to javafx.graphics;
}