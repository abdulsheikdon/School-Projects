package edu.ics372.exam2q1.display;

/**
 * Specifies what the display system should do. Note that the implementation has
 * a lot of freedom to choose its display.
 */
public interface BrushDisplay {
	/**
	 * Displays the time brush has been on
	 * 
	 * @param time total time
	 */
	public void showTimeOn(int time);

	/**
	 * indicate that brush is on
	 */
	public void showBrushOn(String message);

	/**
	 * indicate that brush is off
	 */
	public void showBrushOff();

	/**
	 * indicate that brush is paused
	 */
	public void showBrushPaused();

}