package edu.ics372.exam2q1.display;

import edu.ics372.exam2q1.buttons.GUIButton;
import edu.ics372.exam2q1.buttons.OnOffButton;
import edu.ics372.exam2q1.states.BrushContext;

/**
 * 
 * @author Brahma Dathan and Sarnath Ramnath
 * @Copyright (c) 2010
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * GUI to implement the MicrowaveDisplay interface A pretty elementary interface
 *
 */
public class GUIDisplay extends Application implements BrushDisplay {
	private GUIButton onOffButton;
	private Text brushStatus = new Text("Brush Status");
	private Text timerValue = new Text("            ");
	private static BrushDisplay display;
	private BrushContext brushContext;

	public static BrushDisplay getInstance() {
		return display;
	}

	/**
	 * Sets up the interface
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {
		brushContext = BrushContext.instance();
		brushContext.setDisplay(this);
		display = this;
		onOffButton = new OnOffButton("On/Off");

		GridPane pane = new GridPane();
		pane.setHgap(10);
		pane.setVgap(10);
		pane.setPadding(new Insets(10, 10, 10, 10));
		pane.add(brushStatus, 0, 0);
		pane.add(timerValue, 1, 0);
		pane.add(onOffButton, 2, 0);
		showTimeOn(0);
		Scene scene = new Scene(pane);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Brush Version 1");
		try {
			while (brushContext == null) {
				Thread.sleep(1000);
			}
		} catch (Exception e) {

		}
		primaryStage.show();
		primaryStage.addEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent window) {
				System.exit(0);
			}
		});
	}

	/**
	 * Indicate that the brush is on
	 */
	@Override
	public void showBrushOn(String message) {
		brushStatus.setText(message);
	}

	/**
	 * Indicate that the brush is off
	 */
	@Override
	public void showBrushOff() {
		brushStatus.setText("Brush Off");
	}

	/**
	 * Indicate that the brush is paused
	 */
	@Override
	public void showBrushPaused() {
		brushStatus.setText("Brush Paused");
	}

	@Override
	public void showTimeOn(int time) {
		timerValue.setText(" " + time);

	}

}