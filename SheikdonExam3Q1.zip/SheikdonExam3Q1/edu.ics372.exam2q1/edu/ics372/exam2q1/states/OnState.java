package edu.ics372.exam2q1.states;

import edu.ics372.exam2q1.timer.Notifiable;
import edu.ics372.exam2q1.timer.Timer;

public class OnState extends BrushState implements Notifiable {
	private static OnState instance;
	private Timer timer;

	private OnState() {
	}
	
	public static OnState instance() {
		if (instance == null) {
			instance = new OnState();
		}
		return instance;
	}
	
	@Override
	public void onOnOffPressed() {
		BrushContext.instance().changeState(OffState.instance());
	}

	@Override
	public void onTimerTicked(int timeValue) {
		BrushContext.instance().showTimeOn(timeValue);
	}

	@Override
	public void onTimerRanOut() {
		BrushContext.instance().showTimeOn(0);
		BrushContext.instance().changeState(PausedState.instance());
	}

	@Override
	public void enter() {
		timer = new Timer(this, 10);
		BrushContext.instance().showBrushOn("First Phase");
		BrushContext.instance().showTimeOn(timer.getTimeValue());
	}

	@Override
	public void leave() {
		timer.stop();
		timer = null;
		BrushContext.instance().showTimeOn(0);
	}	

}
