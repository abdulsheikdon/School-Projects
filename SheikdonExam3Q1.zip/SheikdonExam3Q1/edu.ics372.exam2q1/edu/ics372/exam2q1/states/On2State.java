package edu.ics372.exam2q1.states;

import edu.ics372.exam2q1.timer.Notifiable;
import edu.ics372.exam2q1.timer.Timer;

public class On2State extends BrushState implements Notifiable {
	private static On2State instance;
	private Timer timer;

	private On2State() {
	}

	public static On2State instance() {
		if (instance == null) {
			instance = new On2State();
		}
		return instance;
	}
	
	@Override
	public void onOnOffPressed() {
		BrushContext.instance().changeState(OffState.instance());
	}

	@Override
	public void onTimerTicked(int timeValue) {
		BrushContext.instance().showTimeOn(timeValue);
	}

	@Override
	public void onTimerRanOut() {
		BrushContext.instance().showTimeOn(0);
		BrushContext.instance().changeState(OffState.instance());
	}
	
	@Override
	public void enter() {
		timer = new Timer(this, 5);
		BrushContext.instance().showBrushOn("Second Phase");
		BrushContext.instance().showTimeOn(timer.getTimeValue());
	}

	@Override
	public void leave() {
		timer.stop();
		timer = null;
		BrushContext.instance().showTimeOn(0);
	}

}
