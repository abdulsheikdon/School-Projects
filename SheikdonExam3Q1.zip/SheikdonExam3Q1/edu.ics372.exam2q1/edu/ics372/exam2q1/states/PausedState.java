package edu.ics372.exam2q1.states;

import edu.ics372.exam2q1.timer.Notifiable;
import edu.ics372.exam2q1.timer.Timer;

public class PausedState extends BrushState implements Notifiable {
	private static PausedState instance;
	private Timer timer;

	private PausedState() {
	}

	public static PausedState instance() {
		if (instance == null) {
			instance = new PausedState();
		}
		return instance;
	}
	
	@Override
	public void onOnOffPressed() {
		BrushContext.instance().changeState(OffState.instance());
	}

	@Override
	public void onTimerTicked(int timeValue) {
		BrushContext.instance().showTimeOn(timeValue);
	}

	@Override
	public void onTimerRanOut() {
		BrushContext.instance().showTimeOn(0);
		BrushContext.instance().changeState(On2State.instance());
	}

	@Override
	public void enter() {
		timer = new Timer(this, 3);
		BrushContext.instance().showBrushOn("Brush Paused");
		BrushContext.instance().showTimeOn(timer.getTimeValue());
	}

	@Override
	public void leave() {
		timer.stop();
		timer = null;
		BrushContext.instance().showTimeOn(0);
	}


}
