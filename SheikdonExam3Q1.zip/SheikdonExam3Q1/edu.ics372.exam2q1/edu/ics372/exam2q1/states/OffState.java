package edu.ics372.exam2q1.states;


public class OffState extends BrushState {
	private static OffState instance;
	
	public static BrushState instance() {
		if (instance == null) {
			instance = new OffState();
		}
		return instance;
	}
	
	private OffState() {
	}
	
	@Override
	public void onOnOffPressed() {
		BrushContext.instance().changeState(OnState.instance());
	}
	
	@Override
	public void enter() {
		BrushContext.instance().showBrushOn("Brush Off");
	}
	
	@Override
	public void leave() {
	}
}
