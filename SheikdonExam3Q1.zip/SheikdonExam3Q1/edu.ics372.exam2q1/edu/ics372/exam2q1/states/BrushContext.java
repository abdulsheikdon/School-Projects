package edu.ics372.exam2q1.states;

import edu.ics372.exam2q1.display.BrushDisplay;

/**
 * 
 * @author Brahma Dathan and Sarnath Ramnath
 * @Copyright (c) 2010
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */

/**
 * The context is an observer for the clock and stores the context info for
 * states
 *
 */
public class BrushContext {
	private BrushDisplay display;
	private BrushState currentState;
	private static BrushContext instance;
	private int timeOn;

	/**
	 * Make it a singleton
	 */
	private BrushContext() {
		instance = this;
		currentState = OffState.instance();
	}

	/**
	 * Return the instance
	 * 
	 * @return the object
	 */
	public static BrushContext instance() {
		if (instance == null) {
			instance = new BrushContext();
		}
		return instance;
	}

	/**
	 * The display could change. So we have to get its refrence.
	 * 
	 * @param display The current display object
	 */
	public void setDisplay(BrushDisplay display) {
		this.display = display;
	}

	/**
	 * Lets door closed state be the starting state adds the object as an observable
	 * for clock
	 */
	public void initialize() {
		instance.changeState(OnState.instance());
	}

	/**
	 * Called from the states to change the current state
	 * 
	 * @param nextState the next state
	 */
	public void changeState(BrushState nextState) {
		currentState.leave();
		currentState = nextState;
		currentState.enter();
	}

	public void onOnOffPressed() {
		currentState.onOnOffPressed();
	}

	/**
	 * This invokes the right method of the display. This helps protect the states
	 * from changes to the way the system utilizes the state changes.
	 * 
	 * @param time time brush has been on
	 */
	public void showTimeOn(int time) {
		display.showTimeOn(time);
	}

	/**
	 * This invokes the right method of the display. This helps protect the states
	 * from changes to the way the system utilizes the state changes.
	 * 
	 */
	public void showBrushOn(String message) {
		display.showBrushOn(message);
	}

	/**
	 * This invokes the right method of the display. This helps protect the states
	 * from changes to the way the system utilizes the state changes.
	 * 
	 */
	public void showBrushOff() {
		display.showBrushOff();
	}

	/**
	 * This invokes the right method of the display. This helps protect the states
	 * from changes to the way the system utilizes the state changes.
	 * 
	 */
	public void showBrushPaused() {
		display.showBrushPaused();
	}

	public int getTimeOn() {
		return timeOn;
	}

	public void setTimeOn(int timeOn) {
		this.timeOn = timeOn;
	}

}