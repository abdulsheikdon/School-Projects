package edu.ics372.exam2q1.states;

public class BrushState {

	public void onOnOffPressed() {
		// TODO Auto-generated method stub
		
	}

	public void leave() {
		// TODO Auto-generated method stub
		
	}

	public void enter() {
		// TODO Auto-generated method stub
		
	}
	
	public void onTimerRunsOut() {
	}
	
	public void onTimerTick(int timerValue) {

	}
}
