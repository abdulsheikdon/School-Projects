package edu.ics372.exam2q1.buttons;

import edu.ics372.exam2q1.states.BrushContext;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

/**
 * The button for cook request
 * 
 * @author Brahma Dathan
 *
 */
public class OnOffButton extends GUIButton implements EventHandler<ActionEvent> {
	/**
	 * The button for cooking
	 * 
	 * @param string
	 */
	public OnOffButton(String string) {
		super(string);
	}

	@Override
	public void handle(ActionEvent event) {
		BrushContext.instance().onOnOffPressed();
	}
}