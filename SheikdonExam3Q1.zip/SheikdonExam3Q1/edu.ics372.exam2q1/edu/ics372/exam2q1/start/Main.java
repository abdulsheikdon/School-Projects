package edu.ics372.exam2q1.start;

import edu.ics372.exam2q1.display.GUIDisplay;
import edu.ics372.exam2q1.timer.Clock;
import javafx.application.Application;

public class Main {
	public static void main(String[] args) {
		Clock.instance();
		new Thread() {
			@Override
			public void run() {
				Application.launch(GUIDisplay.class, null);
			}
		}.start();
	}
}
