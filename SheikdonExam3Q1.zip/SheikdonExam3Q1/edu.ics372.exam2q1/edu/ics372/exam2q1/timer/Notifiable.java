package edu.ics372.exam2q1.timer;

/**
 * An entity that can be notified of timing events
 * 
 * @author Brahma Dathan
 *
 */
public interface Notifiable {
	/**
	 * Process timer ticks
	 */
	public void onTimerTicked(int timeValue);

	/**
	 * Process timer runs out event
	 */
	public void onTimerRanOut();
}
