public class Consumer implements Runnable {
	private Queue queue;
	private int threadID;

	public Consumer(Queue queue, int threadID) {
		this.queue = queue;
		this.threadID = threadID;
	}

	public void run() {
		while (true) {
			int item = queue.dequeue(threadID);
			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (item == 0 && queue.isQueueEmpty()) {
				break;
			}
		}
	}
}