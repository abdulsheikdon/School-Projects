What I observed was that the amount of times that the Producer enqueued and the Consumer dequeued
when it was synchronized was always the same no matter how many times I ran it. When it wasn't synchronized,
there was always leftover items in the queue. The time it took to run the code was the same in all the trials despite
whether it was synchronized or not.