public class Queue {
	private int[] queue;
	private int front, end, capacity;
	private boolean full, empty;
	
	int producerInstance = 0;
	int consumerInstance = 0;


	public Queue(int size) {
		queue = new int[size];
		capacity = size;
		front = end = 0;
		full = false;
		empty = true;
	}

	public synchronized void enqueue(int item, int threadID) {
		if (!full) {
			queue[end] = item;
			end = (end + 1) % capacity;
			empty = false;
			if (end == front) {
				full = true;
			}
			System.out.println("Producer " + threadID + ": enqueued " + item);
			//Keeping track of how many times it enqueues 
			producerInstance++;
		} else {
			try {
				System.out.println("Producer " + threadID + ": queue is full");
				wait(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public synchronized int dequeue(int threadID) {
		int item = 0;
		if (!empty) {
			item = queue[front];
			front = (front + 1) % capacity;
			full = false;
			if (front == end) {
				empty = true;
			}
			System.out.println("Consumer " + threadID + ": dequeued " + item);
			consumerInstance++;
		} else {
			System.out.println("Consumer " + threadID + ": queue is empty");
		}
		return item;
	}

	public synchronized boolean isQueueEmpty() {
		return empty;
	}

	public synchronized boolean isQueueFull() {
		return full;
	}
}