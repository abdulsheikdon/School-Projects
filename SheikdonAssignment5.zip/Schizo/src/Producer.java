import java.util.concurrent.ThreadLocalRandom;

public class Producer implements Runnable {
	private Queue queue;
	private int threadID;
	public Producer(Queue queue, int threadID) {
		this.queue = queue;
		this.threadID = threadID;
	}

	//randomizing the stuff put into the queue
	public void run() {
		ThreadLocalRandom random = ThreadLocalRandom.current();
		//doing it 100 times
		for (int i = 0; i < 100; i++) {
			int item = random.nextInt(1, 1000);
			queue.enqueue(item, threadID);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
