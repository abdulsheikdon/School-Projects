
class Timer {
    private long start, stop;
    void start() {
        start = System.nanoTime();
    }
    void stop() {
        stop = System.nanoTime();
    }
    long elapsedTime() {
        return stop - start;
    } 
}

public class Main {
	public static void main(String[] args) {
		
		Timer t = new Timer();
		
		t.start();
//		int producerInstance = 0;
//		int consumerInstance = 0;
		
		Queue queue = new Queue(10);

		Thread[] producers = new Thread[2];
		for (int i = 0; i < 2; i++) {
			producers[i] = new Thread(new Producer(queue, i));
			producers[i].start();
//			if (queue.producerInstance > 100) {
//				done = true;
//			}
		}

		Thread[] consumers = new Thread[3];
		for (int i = 0; i < 3; i++) {
			consumers[i] = new Thread(new Consumer(queue, i));
			consumers[i].start();
			
		}

		try {
			for (int i = 0; i < 2; i++) {
				producers[i].join();
				//producerInstance++;
			}
			queue.enqueue(0, -1);
			for (int i = 0; i < 3; i++) {
				consumers[i].join();
				//consumerInstance++;
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		t.stop();
		long queueTime = t.elapsedTime();
		long leftovers = queue.producerInstance - queue.consumerInstance;
		
		System.out.println();
		System.out.println("Instances of Producer queuing: " + queue.producerInstance);
		System.out.println("Instances of Consumer dequeueing: " + queue.consumerInstance);
		System.out.println("Leftover items in the queue: " + leftovers);
		System.out.println("Time passed: " + queueTime + " nanoseconds");
		
	}
}


       
