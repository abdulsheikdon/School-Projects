package com.company;

public class CookiePanel {
}
