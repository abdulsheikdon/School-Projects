package g;

import java.util.Random;

public class CoarseHashMapTest {
    public static void main(String[] args) {
        CoarseHashMap<Integer, String> map = new CoarseHashMap<>(16);

        Thread t1 = new Thread(() -> {
            Random rand = new Random();
            for (int i = 0; i < 10000; i++) {
                map.put(rand.nextInt(1000), "value");
            }
        });

        Thread t2 = new Thread(() -> {
            Random rand = new Random();
            for (int i = 0; i < 10000; i++) {
                map.put(rand.nextInt(1000), "value");
            }
        });

        t1.start();
        t2.start();

        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Size of map: " + map.size());
        System.out.println("Values in map: " + map.values());
        System.out.println("Entries in map: " + map.entrySet());
    }
}


