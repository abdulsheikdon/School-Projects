package g;

import java.util.*;

public class CoarseHashMap<K, T> {
    private int capacity;
    private int size;
    private Node<K, T>[] buckets;

    public CoarseHashMap(int capacity) {
        this.capacity = capacity;
        this.buckets = new Node[capacity];
    }

    public synchronized T put(K key, T item) {
        int hash = key.hashCode();
        int index = hash % capacity;

        Node<K, T> node = buckets[index];
        while (node != null) {
            if (node.key.equals(key)) {
                T oldValue = node.value;
                node.value = item;
                return oldValue;
            }
            node = node.next;
        }

        Node<K, T> newNode = new Node<>(key, item);
        newNode.next = buckets[index];
        buckets[index] = newNode;
        size++;

        if (size >= capacity * 0.75) {
            resize();
        }

        return null;
    }

    public synchronized T get(K key) {
        int hash = key.hashCode();
        int index = hash % capacity;

        Node<K, T> node = buckets[index];
        while (node != null) {
            if (node.key.equals(key)) {
                return node.value;
            }
            node = node.next;
        }

        return null;
    }

    public synchronized int size() {
        return size;
    }

    public synchronized Collection<T> values() {
        List<T> values = new ArrayList<>();
        for (Node<K, T> node : buckets) {
            while (node != null) {
                values.add(node.value);
                node = node.next;
            }
        }
        return values;
    }

    public synchronized Set<Map.Entry<K,T>> entrySet() {
        Set<Map.Entry<K,T>> entries = new HashSet<>();
        for (Node<K, T> node : buckets) {
            while (node != null) {
                Map.Entry<K,T> entry = new AbstractMap.SimpleEntry<>(node.key, node.value);
                entries.add(entry);
                node = node.next;
            }
        }
        return entries;
    }

    private void resize() {
        int newCapacity = capacity * 2;
        Node<K, T>[] newBuckets = new Node[newCapacity];

        for (Node<K, T> node : buckets) {
            while (node != null) {
                int index = node.key.hashCode() % newCapacity;

                Node<K, T> next = node.next;
                node.next = newBuckets[index];
                newBuckets[index] = node;
                node = next;
            }
        }

        buckets = newBuckets;
        capacity = newCapacity;
    }

    private static class Node<K, T> {
        private final K key;
        private T value;
        private Node<K, T> next;

        public Node(K key, T value) {
            this.key = key;
            this.value = value;
        }
    }
}
