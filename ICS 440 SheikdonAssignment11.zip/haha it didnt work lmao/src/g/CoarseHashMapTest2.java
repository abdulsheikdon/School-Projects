package g;

import java.util.Map;
import java.util.Random;

// I tried a different way of printing the results to get a more organized look
public class CoarseHashMapTest2 {
    public static void main(String[] args) {
        CoarseHashMap<Integer, String> map = new CoarseHashMap<>(16);

        Thread t1 = new Thread(() -> {
            Random rand = new Random();
            for (int i = 0; i < 10000; i++) {
                map.put(rand.nextInt(1000), "value");
            }
        });

        Thread t2 = new Thread(() -> {
            Random rand = new Random();
            for (int i = 0; i < 10000; i++) {
                map.put(rand.nextInt(1000), "value");
            }
        });

        t1.start();
        t2.start();

        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        printResults(map);
    }

    private static void printResults(CoarseHashMap<Integer, String> map) {
        System.out.println("Size of map: " + map.size());
        System.out.println("Values in map: ");
        for (String value : map.values()) {
            System.out.println(value);
        }
        System.out.println("Entries in map: ");
        for (Map.Entry<Integer, String> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }
}

