I couldn't get the bat file to work yesterday, but my project works as a whole.
I left two bat files I was able to come up with in here. 
Also, I emailed you last night about my internet connection not letting me submit so I hope there isn't a penalty because
of an instance I couldn't control. Thank you.