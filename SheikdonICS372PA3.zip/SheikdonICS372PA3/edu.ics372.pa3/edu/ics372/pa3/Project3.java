package edu.ics372.pa3;

/**
 * these are the imports needed to successfully utilize the javafx suite
 */
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.Point2D;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * What this class does is it creates a interface that the user can interact
 * with and creates a diamond when you click random spots in the open area and
 * press "Draw"
 * 
 * I used a video on the internet that helped me set up the JavaFX as I had
 * never done it before in a class; I've always used swing
 * 
 * @author Abdullahi Sheikdon
 *
 */

public class Project3 extends Application implements EventHandler<Event> {

	/**
	 * this is where the instance variables are created:
	 * 
	 * @param canvas is the space in which we draw in
	 * @param draw   button creates the diamond when the user clicks
	 * @param exit   button exits the interface
	 * @param click  count counts the clicks
	 * @param canvas width sets the width to 800
	 * @param canvas sets the height to 600;
	 * 
	 */
	private Canvas canvas;
	private Button drawButton, exitButton;
	private GraphicsContext graphicContent;
	private int clickCount;
	private Point2D pt1, pt2;
	private static final int CANVAS_WIDTH = 800;
	private static final int CANVAS_HEIGHT = 600;

	/**
	 * This is the constructor for the instance variable and each one gets
	 * instantiated
	 */
	public Project3() {
		this.canvas = new Canvas(CANVAS_WIDTH, CANVAS_HEIGHT);
		this.drawButton = new Button("Draw");
		this.exitButton = new Button("Exit");
		this.graphicContent = this.canvas.getGraphicsContext2D();
		this.drawButton.addEventHandler(ActionEvent.ACTION, this);
		this.exitButton.addEventHandler(ActionEvent.ACTION, this);
		this.canvas.addEventHandler(MouseEvent.MOUSE_CLICKED, this);
		this.clickCount = 0;
	}

	/**
	 * start() creates the the screen that the user sees scene contains the user's
	 * screen the stage then gets set as the scene so that .show() can show the
	 * screen
	 * 
	 */
	@Override
	public void start(Stage stage) throws Exception {
		VBox base = userScreen();
		Scene scene = new Scene(base);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * userScreen creates a canvas and holds the buttons and adds the buttons draw
	 * and exit to the box that will contain them.
	 * 
	 * @return returns the objects containing the canvas
	 * 
	 */
	private VBox userScreen() {
		VBox object = new VBox();
		object.getChildren().add(this.canvas);
		HBox buttons = new HBox();
		buttons.getChildren().addAll(this.drawButton, this.exitButton);
		object.getChildren().add(buttons);
		return object;
	}

	/**
	 * handle() differentiates what event happens when the screen gets clicked
	 * 
	 * @param event is the event that happens
	 */
	@Override
	public void handle(Event event) {
		EventType eventType = event.getEventType();
		if (eventType == ActionEvent.ACTION)
			buttonClicked((ActionEvent) event);
		else if (eventType == MouseEvent.MOUSE_CLICKED)
			mouseClicked((MouseEvent) event);
	}

	/**
	 * buttonClicked() provides an action or a "button event" for when the button gets
	 * clicked. It gets the button clicked then checks which button it was then does
	 * the appropriate action.
	 * The click gets reset to 0 if it exceeds 2 clicks
	 * 
	 * @param buttonClicked tracks which button is clicked
	 * @param buttonEvent gets given the appropriate action event
	 */
	private void buttonClicked(ActionEvent buttonEvent) {
		Button buttonClicked = (Button) buttonEvent.getSource();
		if (buttonClicked == this.exitButton) {
			System.exit(0);
		} else if (buttonClicked == this.drawButton) {
			if (this.clickCount >= 2) {
				diamond();
				this.clickCount = 0;
				this.pt1 = null;
				this.pt2 = null;
			}
		}
	}

	/**
	 * This method handles teh mouse click event.
	 */
	
	/**
	 * mouseClicked() provides an action or a "click event" for when the button gets
	 * clicked. It increments the clicks made and associates the click with a 
	 * point variable.
	 * @param clickEvent is the amount of time the mouse has been clicked
	 */
	private void mouseClicked(MouseEvent clickEvent) {
		this.clickCount += 1;
		if ((this.clickCount % 2) == 1)
			this.pt1 = new Point2D(clickEvent.getX(), clickEvent.getY());
			this.pt2 = new Point2D(clickEvent.getX(), clickEvent.getY());
	}

	/**
	 * This method draws a diamond on the canvas.
	 */
	
	/**
	 *  diamond() does the math and constructs the diamond. It provides lines for
	 *  the diamond. FIrst it checks if the points are on the same line or column,
	 *  then draws a line between them. In the other case, it gets the third and fourth
	 *  clicked and if the Y value of the second point is bigger than the first point,
	 *  it grabs the third and fourth point and performs some math. In the else case it
	 *  does the opposite. It continues so on and so on. Lastly, it draws the diamond
	 *  symmetrically because otherwise it isn't a diamond if it doesn't maintain its 
	 *  symmetry.
	 * 
	 */
	private void diamond() {
		if ((this.pt1.getY() == this.pt2.getY()) || 
				(this.pt1.getX() == this.pt2.getX())) {
			this.graphicContent.strokeLine(this.pt1.getX(),
					this.pt1.getY(), this.pt2.getX(), this.pt2.getY());
		} else {
			Point2D point3, point4;
			if (this.pt1.getY() > this.pt2.getY()) {
				point3 = new Point2D((2 * this.pt2.getX()) - this.pt1.getX(),
						this.pt1.getY());
				point4 = new Point2D(this.pt2.getX(),
						(2 * this.pt1.getY()) - this.pt2.getY());
			} else {
				point3 = new Point2D(this.pt1.getX(),
						(2 * this.pt2.getY()) - this.pt1.getY());
				point4 = new Point2D((2 * this.pt1.getX()) - this.pt2.getX(),
						this.pt2.getY());
			}

			point3 = new Point2D(this.pt1.getX(),
					(2 * this.pt2.getY()) - this.pt1.getY());
			point4 = new Point2D((2 * this.pt1.getX()) - this.pt2.getX(),
					this.pt2.getY());
			
			this.graphicContent.strokeLine(this.pt1.getX(), this.pt1.getY(),
					this.pt2.getX(), this.pt2.getY());
			this.graphicContent.strokeLine(this.pt2.getX(), this.pt2.getY(),
					point3.getX(), point3.getY());
			this.graphicContent.strokeLine(point3.getX(), point3.getY(),
					point4.getX(), point4.getY());
			this.graphicContent.strokeLine(point4.getX(), point4.getY(),
					this.pt1.getX(), this.pt1.getY());
		}
	}

	/**
	 * launches the program
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);
	}
}
