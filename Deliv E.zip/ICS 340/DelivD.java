import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

public class DelivD {

	private File inputFile;
	private File outputFile;
	private PrintWriter output;
	private Graph graph;
	int[] arr = {};
	Stack<String> path = new Stack<String>();
	//private int edgeDistance;

	//Constructor - DO NOT MODIFY
	public DelivD(File in, Graph gr) {
		inputFile = in;
		graph = gr;

		// Set up for writing to a file
		try {
			// Use input file name to create output file in the same location
			String inputFileName = inputFile.toString();
			String outputFileName = inputFileName.substring(0, inputFileName.length() - 4).concat("_out.txt");
			outputFile = new File(outputFileName);

			// A Printwriter is an object that can write to a file
			output = new PrintWriter(outputFile);
		} catch (Exception x) {
			System.err.format("Exception: %s%n", x);
			System.exit(0);
		}
		
		// Calls the method that will do the work of deliverable D
		runDelivD();

		output.flush();
	}

	//*********************************************************************************
	//               This is where your work starts
	
	private void runDelivD() {
		//Delete these lines when you add functionality
		System.out.println("DelivD:  To be implemented");//Prints to console
		//output.println("DelivD:  To be implemented");//Prints to file
		Collections.sort(graph.getNodeList(), new NodeComparer());
		int n = graph.getNodeList().size()-1;
		int totalDistance = bitonic(n-1,n) + getDistance(n-1,n);
		System.out.println("Shortest bitonic tour has a distance of "
				+ totalDistance);
		System.out.println("Tour is: ");
		Node startingNode = graph.getNodeList().get(n);
		
//		 prints starting node
		System.out.print(startingNode.getAbbrev() + " -> ");
		
		// prints rest of list
		for (Node node : graph.getNodeList()) {
			System.out.print(node.getAbbrev() + " -> ");
		}	
	}
	
	public int bitonic (int i, int j) {
		if (i == 0 && j == 1) {
//			path.push(graph.getNodeList().get(j).getAbbrev());
//			graph.getNodeList().get(j).setPredecessor(i);
			return getDistance(0,1);
		}
		else if (i < j-1) {
//			path.push(graph.getNodeList().get(j).getAbbrev());
			//set pred
			return bitonic(i,j-1) + getDistance(j-1, j);
		}
		else {
			 /** return minimum value of the bitonic
			 do a minimum of the array and then ..........
			 recursive for loop but use k instead of j **/
			int min = Integer.MAX_VALUE;
			for (int k = 0; k < i; k++) {
				int temp = bitonic(k,i) + getDistance(k, j);
				if (min > temp) {
					min = temp;
					
				}
//				path.push(graph.getNodeList().get(k).getAbbrev());
			}
//			set pred
//			path.push(graph.getNodeList().get(j).getAbbrev());
//			return bitonic(k,i) + getDistance(k, j);
			return min;
		}
	}

	private int getDistance(int i, int j) {
		//grab 2 nodes
		Node iNode = graph.getNodeList().get(i); //node at spot i
		Node jNode = graph.getNodeList().get(j); //node at spot j
		
		for (Edge edge : iNode.getOutgoingEdges()) {
			if (jNode.equals(edge.getHead())) {
//				path.push(edge.getHead().getAbbrev());
//				path.push(jNode.getAbbrev());
//				jNode.setChild(iNode);
				return edge.getDistance();
			}
		}
		return 0;
		//return distance of edge
	}
	
	private class NodeComparer implements Comparator<Node> {
		
		@Override
		public int compare(Node node1, Node node2) {
			Double value1 = Double.parseDouble(node1.getValue());
			Double value2 = Double.parseDouble(node2.getValue());
			if (value1 > value2) {
				return 1;
			} else if (value1 < value2) {
				return -1;
			} else {
				return 0;
			}
		}
	}

}

