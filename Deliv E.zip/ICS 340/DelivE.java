import java.io.File;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.concurrent.TimeUnit;

/** I decided to let the collections.shuffle decide where in the file it would start. 
 *  I decided that to create that randomness.
 *  I decided to continue running the code over the course of 2 nanoseconds or until
 *  the code detected a repeated output of the distance; then the code would stop and print the
 *  current graph.getNodeList(). I feel as though I had the right idea coming in and had
 *  I had the right code to print distance, I'd get the correct output.
 * 
 * 
 * @author abdul
 *
 */


public class DelivE {

	private File inputFile;
	private File outputFile;
	private PrintWriter output;
	private Graph graph;
	private int totalDistance;
	private int amount;
	private int untilStop;

	//Constructor - DO NOT MODIFY
	public DelivE(File in, Graph gr) {
		inputFile = in;
		graph = gr;

		// Set up for writing to a file
		try {
			// Use input file name to create output file in the same location
			String inputFileName = inputFile.toString();
			String outputFileName = inputFileName.substring(0, inputFileName.length() - 4).concat("_out.txt");
			outputFile = new File(outputFileName);

			// A Printwriter is an object that can write to a file
			output = new PrintWriter(outputFile);
		} catch (Exception x) {
			System.err.format("Exception: %s%n", x);
			System.exit(0);
		}
		
		// Calls the method that will do the work of deliverable E
		runDelivE();

		output.flush();
	}

	//*********************************************************************************
	//               This is where your work starts
	
	private void runDelivE() {
		//Delete these lines when you add functionality
		System.out.println("DelivE:  To be implemented");//Prints to console
//		output.println("DelivE:  To be implemented");//Prints to file
//		Collections.shuffle(graph.getNodeList());
//		for (Node node : graph.getNodeList()) {
//			System.out.print(node.getAbbrev() + "->");
//		}
//		System.out.println();
		untilStop = 0;
		amount = 0;
		for (long stop=System.nanoTime()+TimeUnit.SECONDS.toNanos(2);stop>System.nanoTime();) {
			  /*
			   * Hammer the JVM with junk
			   */
			goofyAhhDelivE();
			if (untilStop < totalDistance) {
				break;
				}
			System.out.println("The final path is: ");
//			System.out.println();
			for (Node node : graph.getNodeList()) {
				System.out.print(node.getAbbrev() + "->");
				}
			}
		
	}
	
	public void goofyAhhDelivE() {
		amount++;
		totalDistance = 0;
		Collections.shuffle(graph.getNodeList());
		int n = graph.getNodeList().size()-1;
//		totalDistance = getDistance(n-1,n);
		getDistance();
		System.out.println("Path " + amount + ": ");
		for (Node node : graph.getNodeList()) {
			System.out.print(node.getAbbrev() + "->");
		}
		System.out.println();
		System.out.println("Distance: ");
		System.out.println(totalDistance);
		if (untilStop > totalDistance) {
			untilStop = totalDistance;
			}
		
	}
	
//	public void getDistance() {
//		//grab 2 nodes
//		
//		
////		for (Edge allEdges : graph.getEdgeList()) {
//		for (Edge edgey: graph.getEdgeList()) {
//			Node u = edgey.getTail();
//			Node v = edgey.getHead();
//			for (Edge edge : u.getOutgoingEdges()) {
//				if (v.equals(u)) {
////				path.push(edge.getHead().getAbbrev());
////				path.push(jNode.getAbbrev());
////				jNode.setChild(iNode);
//					totalDistance = totalDistance + edge.getDistance();
//				}
//			}
//		}
////		}
//		//return distance of edge
//	}
	
	public void getDistance() {
		PriorityQueue<Node> Q = new PriorityQueue<Node>();
		for (Node u : graph.getNodeList()) {
			Q.add(u);// adds all the nodes
		}
		while (!Q.isEmpty()) {
			Node u = Q.poll();
			for (Edge edge : u.getOutgoingEdges()) {
				Node v = edge.getHead();
				if (Q.contains(v)) {
					v.setKey(edge.getDistance());
					Q.remove(v);
					Q.add(v);
					}
				}
			Q.remove(u);
			totalDistance = totalDistance + u.getKey();
			}
		}

}