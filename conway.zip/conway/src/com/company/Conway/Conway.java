package com.company.Conway;
import java.util.Random;
import java.util.Scanner;

public class Conway {

    public static void main(String[] args) {
        int height, width;
        Random random;
        if (args.length == 3) {
            height = Integer.parseInt(args[0]);
            width = Integer.parseInt(args[1]);
            int seed = Integer.parseInt(args[2]);
            random = new Random(seed);
        }
        else if (args.length == 2){
            height = Integer.parseInt(args[0]);
            width = Integer.parseInt(args[1]);
            random = new Random();
        }
        else if (args.length == 1){
            height = Integer.parseInt(args[0]);
            width = height;
            random = new Random();
        }
        else {
            height = 5;
            width = 5;
            random = new Random();
        }
        boolean[][] gameBoard = setup(height, width, random);
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to Conway's game of life. To start, press enter.");
        printGame(gameBoard);
        while (input.nextLine(). equals("")){
            gameBoard = update(gameBoard);
            printGame(gameBoard);
        }
        System.out.println("The loop has ended");
    }

    public static boolean[][] setup(int height, int width, Random random) {
        boolean[][] gameBoard = new boolean[height][width];
        double probability = 0.6;
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                double randomVariable = random.nextDouble();
                if (randomVariable < probability) {
                    gameBoard[i][j] = false;
                }
                if (randomVariable >= probability) {
                    gameBoard[i][j] = true;
                }
            }
        }
        return gameBoard;
    }

    public static void printGame(boolean[][] grid) {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j]){
                    System.out.print('o');
                }
                else {
                    System.out.print('x');
                }
            }
            System.out.println();
        }
        System.out.println();
    }

    public static int countNeighbors(boolean[][] grid, int row, int col) {
        int count = 0;
        for (int i = row - 1; i <= row + 1; i++) {
            if (i >= 0 && i < grid.length) {
                for (int j = col - 1; j <= col + 1; j++) {
                    if (j >= 0 && j < grid[i].length) {
                        if (i != row || j != col) {
                            if (grid[i][j]) {
                                count++;
                            }
                        }
                    }
                }
            }
        }
        return count;
    }

    public static boolean[][] update(boolean[][] oldGrid) {
        boolean[][] newGrid  = new boolean[oldGrid.length][oldGrid[0].length];
        for (int row = 0; row < oldGrid.length; row++) {
            for (int col = 0; col < oldGrid[row].length; col++) {
                int neighborCount = countNeighbors(oldGrid, row, col);
                if (oldGrid[row][col]) {
                    newGrid[row][col] = neighborCount == 2||neighborCount ==3;
                }
                else {
                    newGrid[row][col] = neighborCount == 3;
                }
            }
        }
        return newGrid;
    }
}