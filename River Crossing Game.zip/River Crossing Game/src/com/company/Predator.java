package com.company;

import java.util.Set;

public class Predator extends Traveler {
    private Set<String> prey;
    private Set<String> proctors;

    public Predator(int weight, String description, boolean canRow) {
		
    }

    public boolean safetyCheck(Set<Traveler> neighbors) {
		
    }

    public static Predator makeGoose(int weight) {
		
    }

    public static Predator makeFox(int weight) {
		
    }

    public static Predator makeFireElemental(int weight) {
		
    }

    public static Predator makeWaterElemental(int weight) {
		
    }

    public static Predator makeLich(int weight) {
		
    }
}
