package com.company;

import java.util.Set;

public class Boat {
    private int weightLimit;
    private int sizeLimit;

    public Boat(int weightLimit, int sizeLimit) {
		
    }

    public int getSizeLimit() {
		
    }

    public int getWeightLimit() {
		
    }

    public boolean checkAllowed(Set<Traveler> toTransit) {
		
    }
}
