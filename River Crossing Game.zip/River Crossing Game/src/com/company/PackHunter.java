package com.company;

import java.util.Set;

public class PackHunter extends Traveler {
    private Set<String> prey;

    public PackHunter(int weight, String description, boolean canRow) {
		
    }

    public boolean safetyCheck(Set<Traveler> neighbors) {
		
    }

    public static PackHunter makeMonster(int weight) {
		
    }


}
