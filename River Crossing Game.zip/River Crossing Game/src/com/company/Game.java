package com.company;

import java.util.List;

public class Game {
    private List<Traveler> firstBank;
    private List<Traveler> secondBank;
    private Boat boat;

    public Game(List<Traveler> firstBank, Boat boat) {
		
    }

    public boolean play(Scanner input) {
		
    }

}
