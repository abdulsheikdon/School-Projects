package com.company;

import java.util.Set;

public class Traveler {
    protected int weight;
    protected String description;
    protected boolean canRow;

    public Traveler(int weight, String description, boolean canRow) {
        
    }

    public boolean safetyCheck(Set<Traveler> neighbors) {
        
    }

    public boolean canRow() {
        
    }

    public int getWeight() {
        
    }

    public String toString() {
		
    }

    public static Traveler makeGrain(int weight) {
        
    }

    public static Traveler makeMunchkin(int weight) {
        
    }

    public static Traveler makeHuman(int weight) {
        
    }

    public static Traveler makePyromancer(int weight) {
        
    }

    public static Traveler makeHydromancer(int weight) {
        
    }

    public static Traveler makeNecromancer(int weight) {
        
    }
}
