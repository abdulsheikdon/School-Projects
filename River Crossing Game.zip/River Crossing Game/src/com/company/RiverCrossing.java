package com.company;

public class RiverCrossing {

    public static void main(String[] args) {
		System.out.print.ln

    }

    public static Game parseGame(String filepath) throws IOException {
		
    }
}
